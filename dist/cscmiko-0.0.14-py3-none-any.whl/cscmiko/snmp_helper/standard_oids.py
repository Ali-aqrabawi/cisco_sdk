interface_oids = {
    'name': 'ifName',
    'mtu': 'ifMtu',
    'speed': 'ifSpeed',
    'mac': 'ifPhysAddress',
    'admin_status': 'ifAdminStatus',
    'oper_status': 'ifOperStatus',
    'description': 'ifAlias',
    'inErros': 'ifInErrors',
    'inDiscards': 'ifInDiscards',
    'outErrors': 'ifOutErrors',
    'outDiscards': 'ifOutDiscards'

}
