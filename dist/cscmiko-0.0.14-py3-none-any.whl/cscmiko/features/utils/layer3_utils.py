ROUTE_PROTOCOL = dict(C='connected', D='eigrp', O='ospf', S='static', B='bgp', R='rip')
