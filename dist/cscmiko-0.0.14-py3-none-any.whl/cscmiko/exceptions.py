class CscmikoNotSyncedError(Exception):
    pass

class CscmikoInvalidFeatureError(Exception):
    pass
