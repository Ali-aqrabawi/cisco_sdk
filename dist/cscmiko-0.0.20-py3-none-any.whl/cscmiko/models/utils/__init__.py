from .layer2_utils import translate_interface_name, clean_link_status, cidr_to_netmask, exteract_software_version, \
    extract_device_name,is_switchport

from.layer3_utils import ROUTE_PROTOCOL