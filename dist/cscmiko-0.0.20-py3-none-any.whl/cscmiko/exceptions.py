class CscmikoNotSyncedError(Exception):
    pass

class CscmikoInvalidFeatureError(Exception):
    pass


class CiscoSDKSSHAuthenticationError(Exception):
    pass


class CiscoSDKSSHTimeoutError(Exception):
    pass