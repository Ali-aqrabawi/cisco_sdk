from cscmiko.devices.switches.catalyst.generic import CatSwitch
from cscmiko.devices.switches.nexus.generic import NexusSwitch

__all__ = ['CatSwitch', 'NexusSwitch']
